# coding=utf-8

"""
Module to display movie object, attributes and instances
main Python script to run
"""

import fresh_tomatoes
import media


# Movie Objects
pairates = media.MovieTrailer("Pirates of the Caribbean: 5",
                       "Thrust into an all-new adventure, " +
                       "a down-on-his-luck Capt. " +
                       "Jack Sparrow feels the winds of " +
                       "ill-fortune blowing even more " +
                       "strongly when deadly ghost sailors " +
                       "led by his old nemesis, " +
                       "the evil Capt. Salazar, escape " +
                       "from the Devil's Triangle. " +
                       "Jack's only hope of survival lies " +
                       "in seeking out the legendary " +
                       "Trident of Poseidon, but to find it, " +
                       "he must forge an uneasy " +
                       "alliance with a brilliant and " +
                       "beautiful astronomer and a " +
                       "headstrong young man in the British navy.",
                       "https://upload.wikimedia.org/wikipedia/en/2/21/Pirates_of_the_Caribbean%2C_Dead_Men_Tell_No_Tales.jpg",  # noqa
                       "https://www.youtube.com/watch?v=IPf4rGw3XHw")

car = media.MovieTrailer("Cars 3",
                  "Blindsided by a new generation " +
                  "of blazing-fast cars, the legendary " +
                  "Lighting McQueen himself pushed out " +
                  "of the sport that he loves. Hoping to " +
                  "get back in the game, he turns to Cruz " +
                  "Ramirez, an eager young technician who " +
                  "has her own plans for winning. With " +
                  "inspiration from the Fabulous Hudson Hornet " +
                  "and a few unexpected turns, No. 95 prepares " +
                  "to compete on Piston Cup Racing's biggest stage.",
                  "https://upload.wikimedia.org/wikipedia/en/9/94/Cars_3_poster.jpg",  # noqa
                  "https://www.youtube.com/watch?v=2LeOH9AGJQM")
nfs = media.MovieTrailer("Need for Speed",
                  "Tobey Marshall (Aaron Paul), a mechanic, " +
                  "races muscle cars in an underground circuit. " +
                  "Struggling to keep his business afloat, he " +
                  "reluctantly partners with wealthy but " +
                  "treacherous Dino Brewster (Dominic Cooper). " +
                  "However, Dino frames Tobey for a crime that " +
                  "sends him to prison. Two years later, Tobey is " +
                  "out and bent on revenge; his only chance to take " +
                  "down Dino is to beat him in a high-stakes race. " +
                  "But to get there in time, he must successfully evade " +
                  "an army of cops and bounty hunters.",
                  "https://upload.wikimedia.org/wikipedia/en/e/e3/Need_For_Speed_poster.jpg",  # noqa
                  "https://www.youtube.com/watch?v=H_5t589hePA")
# Creating list for movie objects
movies = [pairates, nfs, car]
fresh_tomatoes.open_movies_page(movies)
