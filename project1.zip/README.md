For Movie trailer project
All the files in the zip should be in one place. Dont change the location of any file.
If You are using IDLE Compiler
   Just run entertainment.py file.
If your are using Git compiler( For Windows)
  step1:open git bash
  step2:compile and run the entertainment.py(compile command filename.py)
